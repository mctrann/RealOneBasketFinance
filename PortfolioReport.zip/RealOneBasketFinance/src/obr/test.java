package obr;

public class test {

	public static void main(String args[]){	
		PortfolioData d = new PortfolioData();
		d.addPerson("dkf", "eric", "Le", null, null, "Nebraska", "dfadf", "fdaf", "d", "pprd");
	}
}
