package obr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//information to login into the database
public class DatabaseInfo {
    public static final String url = "jdbc:mysql://cse.unl.edu/ele";
    public static final String username = "ele";
    public static final String password = "Px4:pj";
}

